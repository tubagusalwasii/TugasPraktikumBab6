package com.dicoding.habitapp.ui.add

import android.os.AsyncTask
import androidx.lifecycle.ViewModel
import com.dicoding.habitapp.data.Habit
import com.dicoding.habitapp.data.HabitRepository

class AddHabitViewModel(private val habitRepository: HabitRepository) : ViewModel() {
    fun saveHabit(habit: Habit) {
        InsertHabitAsyncTask(habitRepository).execute(habit)
    }

    private class InsertHabitAsyncTask(private val habitRepository: HabitRepository) :
        AsyncTask<Habit, Void, Void>() {

        override fun doInBackground(vararg habits: Habit): Void? {
            habitRepository.insertHabit(habits[0])
            return null
        }
    }
}