package com.example.gotani.fragments.shopping

import androidx.fragment.app.Fragment
import com.example.gotani.R

class SearchFragment: Fragment(R.layout.fragment_search) {
}